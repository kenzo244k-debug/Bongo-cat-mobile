# Bongo Cat Mobile — arquivos para conversor web → APK

## O que está incluído

- `web-para-conversor/`: página pronta, com `index.html`, `app.js` e `styles.css`. Não requer instalação de dependências para abrir.
- `codigo-fonte/`: código editável do projeto original e o exportador.

## Como usar no conversor

1. Se ele aceita arquivos HTML ou ZIP, envie os arquivos de `web-para-conversor/`, mantendo os três juntos. Escolha `index.html` como página inicial e habilite JavaScript.
2. Se ele aceita somente um endereço de site, será necessário hospedar a página e informar o endereço publicado. Não use o endereço privado da prévia como entrega definitiva.
3. Gere o APK pela ferramenta escolhida e teste no seu Android. O pacote entregue é um ZIP, não um APK compilado ou assinado.

O conversor exato não foi informado; a compatibilidade com ele e com seu aparelho ainda não está verificada. As fontes usam substitutos locais caso as fontes do site não estejam disponíveis.

## O que funciona nesta versão

O gato responde a WASD, Espaço, cliques e movimentos do mouse **dentro da página aberta**, além dos controles de tamanho, posição e pausa. Quando o Free Fire está na frente, esta página não recebe os comandos do jogo.

## Importante: por cima do Free Fire e na live

**Um conversor web comum não entrega essas funções sozinho.** Este pacote não contém janela flutuante Android, serviço em segundo plano, câmera virtual nem leitor de comandos de outros aplicativos.

Para aparecer por cima do jogo, é necessário um aplicativo Android nativo com permissão de sobreposição e uma janela que não bloqueie os toques do jogo. Essa permissão, sozinha, NÃO permite ler teclado ou mouse de outro app. A captura de comandos depende de uma integração nativa compatível e verificada no aparelho. Não há ponte nativa ativa neste código; ativar acessibilidade não garante captura de mouse/teclado do jogo.

Uma transmissão pode incluir a janela flutuante somente se o gravador utilizado a capturar. Alguns gravadores capturam apenas o aplicativo escolhido e excluem sobreposições. Isso exige teste real com Free Fire, aparelho e gravador. Não é uma webcam virtual e não substitui a câmera de outro aplicativo.

**Não é possível afirmar que este ZIP ficará “tudo funcionando no Free Fire” depois de passar por qualquer conversor.** Ele entrega a parte web existente para conversão; a parte nativa ainda precisa ser implementada e validada.

## Para quem vai editar o código

Na pasta `codigo-fonte`, instale com `bun install`. Use `bun run dev` para o projeto original. Para gerar novamente os arquivos web, execute `bun scripts/export-web-package.ts /tmp/bongo-web-export` (precisa de Bun e das dependências instaladas).

O exportador mantém o SVG React e o hook de entrada originais, sem conectar eventos externos. Não altere o roteamento TanStack do projeto original para empacotar a cópia estática.