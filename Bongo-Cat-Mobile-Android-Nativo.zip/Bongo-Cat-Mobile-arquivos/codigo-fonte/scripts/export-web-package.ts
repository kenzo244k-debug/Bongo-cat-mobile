import { compile } from '@tailwindcss/node';
import { Scanner } from '@tailwindcss/oxide';
import { mkdtemp, mkdir, readFile, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';

// This exports a browser-only copy, never an Android overlay or input bridge.
const root = process.cwd();
const destination = process.argv[2];
if (!destination) throw new Error('Informe uma pasta de saída fora do projeto.');
const out = path.resolve(destination);
if (out === root || out.startsWith(`${root}/src`)) throw new Error('Use uma pasta de saída separada.');
await mkdir(out, { recursive: true });
const staging = await mkdtemp(path.join(tmpdir(), 'bongo-export-'));
const original = await readFile(path.join(root, 'src/routes/index.tsx'), 'utf8');
const start = original.indexOf('export const Route =');
const end = original.indexOf('const positions =', start);
if (start < 0 || end < 0) throw new Error('Estrutura da página não reconhecida.');
const page = (original.slice(0, start) + original.slice(end))
  .replace("import { createFileRoute } from '@tanstack/react-router';\n", '')
  .replace('function Index() {', 'export function Index() {')
  .replace(/from '@\/([^']+)'/g, (_, file: string) => `from '${path.join(root, 'src', file)}'`);
await writeFile(path.join(staging, 'page.tsx'), page);
await writeFile(path.join(staging, 'entry.tsx'), `import { createRoot } from '${path.join(root, 'node_modules/react-dom/client')}';\nimport { Index } from './page';\nconst root = document.getElementById('app');\nif (root) createRoot(root).render(<Index />);\n`);
const result = await Bun.build({
  entrypoints: [path.join(staging, 'entry.tsx')],
  target: 'browser', minify: true,
  define: { 'process.env.NODE_ENV': '"production"' },
  plugins: [{ name: 'project-alias', setup(builder) {
    builder.onResolve({ filter: /^@\// }, args => ({ path: path.join(root, 'src', args.path.slice(2)) + (args.path.includes('/lib/') ? '.ts' : '.tsx') }));
  } }],
});
if (!result.success) throw new Error(result.logs.map(String).join('\n'));
const output = result.outputs.find(file => file.kind === 'entry-point');
if (!output) throw new Error('Arquivo JavaScript não gerado.');
await writeFile(path.join(out, 'app.js'), await output.text());
const compiler = await compile(await readFile(path.join(root, 'src/styles.css'), 'utf8'), { base: path.join(root, 'src'), onDependency: () => {} });
const scanner = new Scanner({ sources: [{ base: path.join(root, 'src'), pattern: '**/*.{ts,tsx}', negated: false }] });
await writeFile(path.join(out, 'styles.css'), compiler.build(scanner.scan()));
await writeFile(path.join(out, 'index.html'), `<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Bongo Cat Mobile — Demonstração web</title><meta name="description" content="Bongo Cat interativo com teclado e mouse dentro desta página. Não captura comandos de outros aplicativos.">
<meta property="og:title" content="Bongo Cat Mobile — Demonstração web"><meta property="og:description" content="Gatinho interativo com patinhas animadas."><meta property="og:type" content="website"><meta name="twitter:card" content="summary">
<link rel="stylesheet" href="./styles.css"></head><body><div id="app"></div><script src="./app.js"></script></body></html>`);
console.log('Exportação web concluída. Não inclui APK, sobreposição nativa nem captura de comandos de outros apps.');