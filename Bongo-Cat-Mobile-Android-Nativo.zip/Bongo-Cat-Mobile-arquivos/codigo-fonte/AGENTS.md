<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the Bongo Cat character as an inline React SVG so paw states respond instantly without adding image payloads.
- Keep browser demo input in a dedicated hook and never connect it to cross-app Android events without a verified native bridge; this separates the demo from future native integration.
- Export browser-converter deliverables through a separate packaging script that reuses the existing page, SVG and input hook without changing TanStack routing; generic APK wrappers cannot supply native overlay or cross-app events.
