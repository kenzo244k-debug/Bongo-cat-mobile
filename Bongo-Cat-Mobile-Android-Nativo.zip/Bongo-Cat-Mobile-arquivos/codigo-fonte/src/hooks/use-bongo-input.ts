import { useCallback, useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';

export type DemoInput = 'W' | 'A' | 'S' | 'D' | 'SPACE' | 'LEFT' | 'RIGHT';
export function useBongoInput() {
  const [pressed, setPressed] = useState<Set<DemoInput>>(new Set());
  const [count, setCount] = useState(0);
  const [lastInput, setLastInput] = useState<DemoInput | null>(null);
  const [mouseOffset, setMouseOffset] = useState({ x: 0, y: 0 });
  const previousPointer = useRef<{ x: number; y: number } | null>(null);
  const pointerKeys = useRef(new Map<number, DemoInput>());
  const timers = useRef<Partial<Record<DemoInput, ReturnType<typeof setTimeout>>>>({});
  const held = useRef(new Set<DemoInput>());
  const press = useCallback((key: DemoInput) => {
    if (held.current.has(key)) return;
    held.current.add(key);
    setPressed(new Set(held.current));
    setCount(n => n + 1);
    setLastInput(key);
  }, []);
  const release = useCallback((key: DemoInput) => {
    held.current.delete(key);
    setPressed(new Set(held.current));
  }, []);
  const tap = useCallback((key: DemoInput) => {
    clearTimeout(timers.current[key]);
    press(key);
    timers.current[key] = setTimeout(() => release(key), 180);
  }, [press, release]);
  const inputHandlers = (key: DemoInput) => ({
    onPointerDown: (event: ReactPointerEvent<HTMLButtonElement>) => {
      event.preventDefault();
      event.currentTarget.setPointerCapture(event.pointerId);
      pointerKeys.current.set(event.pointerId, key);
      press(key);
    },
    onPointerUp: (event: ReactPointerEvent<HTMLButtonElement>) => {
      pointerKeys.current.delete(event.pointerId);
      release(key);
    },
    onPointerCancel: (event: ReactPointerEvent<HTMLButtonElement>) => {
      pointerKeys.current.delete(event.pointerId);
      release(key);
    },
    onLostPointerCapture: () => release(key),
    onClick: (event: React.MouseEvent<HTMLButtonElement>) => { if (event.detail === 0) tap(key); },
  });
  const moveMouse = useCallback((x: number, y: number) => {
    const previous = previousPointer.current;
    previousPointer.current = { x, y };
    if (!previous) return;
    setMouseOffset(current => ({
      x: Math.max(-22, Math.min(22, current.x + (x - previous.x) * .18)),
      y: Math.max(-14, Math.min(14, current.y + (y - previous.y) * .18)),
    }));
  }, []);
  const stageHandlers = {
    onPointerDown: (event: ReactPointerEvent<HTMLDivElement>) => {
      previousPointer.current = { x: event.clientX, y: event.clientY };
      event.currentTarget.setPointerCapture(event.pointerId);
      const key: DemoInput = event.button === 2 ? 'RIGHT' : 'LEFT';
      pointerKeys.current.set(event.pointerId, key);
      press(key);
    },
    onPointerMove: (event: ReactPointerEvent<HTMLDivElement>) => {
      if (event.pointerType !== 'mouse') moveMouse(event.clientX, event.clientY);
    },
    onPointerUp: (event: ReactPointerEvent<HTMLDivElement>) => {
      const key = pointerKeys.current.get(event.pointerId);
      if (key) release(key);
      pointerKeys.current.delete(event.pointerId);
    },
    onPointerCancel: (event: ReactPointerEvent<HTMLDivElement>) => {
      const key = pointerKeys.current.get(event.pointerId);
      if (key) release(key);
      pointerKeys.current.delete(event.pointerId);
      previousPointer.current = null;
    },
    onContextMenu: (event: React.MouseEvent<HTMLDivElement>) => event.preventDefault(),
  };
  useEffect(() => {
    const mapKey = (event: KeyboardEvent): DemoInput | null => {
      const target = event.target;
      if (target instanceof HTMLElement && (target.matches('input, textarea, [role="slider"], [role="switch"]') || target.isContentEditable)) return null;
      if (event.code === 'Space' && target instanceof HTMLElement && target.closest('button')) return null;
      const key = event.key.toUpperCase();
      return ['W', 'A', 'S', 'D'].includes(key) ? key as DemoInput : event.code === 'Space' ? 'SPACE' : null;
    };
    const down = (event: KeyboardEvent) => { const key = mapKey(event); if (key) { event.preventDefault(); press(key); } };
    const up = (event: KeyboardEvent) => { const key = event.code === 'Space' ? 'SPACE' : event.key.toUpperCase() as DemoInput; release(key); };
    const clear = () => { held.current.clear(); pointerKeys.current.clear(); previousPointer.current = null; setPressed(new Set()); };
    const move = (event: PointerEvent) => { if (event.pointerType === 'mouse') moveMouse(event.clientX, event.clientY); };
    const pointerUp = (event: PointerEvent) => {
      const key = pointerKeys.current.get(event.pointerId);
      if (key) release(key);
      pointerKeys.current.delete(event.pointerId);
    };
    const visibility = () => { if (document.hidden) clear(); };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    window.addEventListener('blur', clear);
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', pointerUp);
    window.addEventListener('pointercancel', pointerUp);
    document.addEventListener('visibilitychange', visibility);
    return () => {
      window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); window.removeEventListener('blur', clear);
      window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', pointerUp); window.removeEventListener('pointercancel', pointerUp);
      document.removeEventListener('visibilitychange', visibility);
      Object.values(timers.current).forEach(clearTimeout);
    };
  }, [press, release, moveMouse]);
  return { pressed, count, lastInput, inputHandlers, stageHandlers, mouseOffset };
}