import type { DemoInput } from '@/hooks/use-bongo-input';

type BongoCatProps = { pressed: Set<DemoInput>; mouseOffset: { x: number; y: number }; enabled: boolean; size?: number };

const keyCells: Record<string, DemoInput> = { '1-2': 'W', '2-1': 'A', '2-2': 'S', '2-3': 'D' };
const keyTargets: Partial<Record<DemoInput, { x: number; y: number }>> = {
  W: { x: 196, y: 224 }, A: { x: 176, y: 235 }, S: { x: 193, y: 235 }, D: { x: 210, y: 236 }, SPACE: { x: 270, y: 251 },
};

export function BongoCat({ pressed, mouseOffset, enabled, size = 100 }: BongoCatProps) {
  const keyboardKeys = [...pressed].filter(key => keyTargets[key]);
  const activeKey = enabled ? keyboardKeys.at(-1) : undefined;
  const target = activeKey ? keyTargets[activeKey] : undefined;
  const x = enabled ? mouseOffset.x : 0;
  const y = enabled ? mouseOffset.y : 0;
  const mousePressed = enabled && (pressed.has('LEFT') || pressed.has('RIGHT'));
  const mouseX = 97 + x;
  const mouseY = 217 + y + (mousePressed ? 5 : 0);
  return (
    <svg className="bongo-cat" width={size * 3.6} viewBox="0 0 440 300" role="img" aria-label="Gatinho branco com teclado e mouse">
      <ellipse className="cat-shadow" cx="226" cy="264" rx="180" ry="15" />
      <path className="cat-body" d="M108 186 Q99 130 127 96 L140 50 Q144 38 156 47 L187 68 Q225 56 263 69 L298 45 Q311 35 313 52 L319 99 Q350 134 336 193 Z" />
      <path className="cat-ear" d="M145 60 L153 83 L170 75 Z M299 58 L281 77 L306 85 Z" />
      <ellipse className="cat-ink" cx="190" cy="117" rx="6" ry="8" />
      <ellipse className="cat-ink" cx="268" cy="117" rx="6" ry="8" />
      <path className="cat-mouth" d="M215 125 Q215 139 228 133 Q239 143 246 129" />
      <ellipse className="cat-blush" cx="173" cy="135" rx="13" ry="6" />
      <ellipse className="cat-blush" cx="285" cy="135" rx="13" ry="6" />
      <path className="desk-line" d="M18 196 H421" />
      <path className="mouse-pad" d="M45 205 L117 211 L132 255 L28 247 Z" />
      <g className="tracked-mouse" transform={`translate(${x} ${y})`}>
        <path className="cat-mouse" d="M65 220 Q78 199 97 216 L105 235 Q88 251 63 235 Z" />
        <path className={`mouse-click-half ${enabled && pressed.has('LEFT') ? 'mouse-click-active' : ''}`} d="M65 220 Q71 209 83 211 L78 229 L64 231 Z" />
        <path className={`mouse-click-half ${enabled && pressed.has('RIGHT') ? 'mouse-click-active' : ''}`} d="M83 211 Q94 211 100 222 L102 232 L78 229 Z" />
        <path className="mouse-line" d="M83 213 L78 229 M68 224 L98 228" />
      </g>
      <path className="keyboard-base" d="M153 201 L369 208 L403 264 L136 253 Z" />
      <path className="keyboard-edge" d="M136 253 L403 264 L399 272 L137 261 Z" />
      {Array.from({ length: 4 }, (_, row) => Array.from({ length: 12 }, (_, col) => {
        const key = keyCells[`${row}-${col}`];
        return <g key={`${row}-${col}`}>
          <path data-cat-key={key} className={`cat-key ${enabled && key && pressed.has(key) ? 'cat-key-active' : ''}`} d={`M${158 + col * 17 - row * 3} ${207 + row * 11 + col * .5} l14 .5 l5 8 l-15 -.5 Z`} />
          {key && <text className="cat-key-label" x={167 + col * 17 - row * 3} y={213 + row * 11 + col * .5}>{key}</text>}
        </g>;
      }))}
      <path data-cat-key="SPACE" className={`cat-key cat-space ${enabled && pressed.has('SPACE') ? 'cat-key-active' : ''}`} d="M206 246 L319 250 L324 258 L204 254 Z" />
      <g className="cat-paw paw-mouse" data-pressed={mousePressed}><path d={`M142 168 Q134 161 119 175 L${mouseX - 13} ${mouseY - 15} Q${mouseX - 28} ${mouseY + 1} ${mouseX - 15} ${mouseY + 9} Q${mouseX + 2} ${mouseY + 18} ${mouseX + 19} ${mouseY + 1} L151 194`} /></g>
      <g className="cat-paw paw-keys" data-key={activeKey ?? 'idle'}><path d={target ? `M294 168 Q308 165 307 188 L${target.x + 15} ${target.y - 8} Q${target.x + 17} ${target.y + 5} ${target.x} ${target.y + 6} Q${target.x - 18} ${target.y + 5} ${target.x - 16} ${target.y - 8} L280 190` : 'M294 168 Q318 166 324 188 L333 220 Q335 240 317 242 Q298 242 292 224 L280 190'} /></g>
      {mousePressed && <g className="tap-sparks" transform={`translate(${x} ${y})`}><path d="M59 205 l-8 -7 M55 221 H44 M63 240 l-9 6" /></g>}
      {target && <g className="tap-sparks" transform={`translate(${target.x} ${target.y})`}><path d="M24 -5 l7 -4 M25 7 h8 M21 18 l6 5" /></g>}
    </svg>
  );
}