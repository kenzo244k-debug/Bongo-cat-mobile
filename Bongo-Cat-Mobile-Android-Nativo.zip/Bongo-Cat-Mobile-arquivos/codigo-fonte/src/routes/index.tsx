import { createFileRoute } from '@tanstack/react-router';
import { useState } from 'react';
import { ArrowDownLeft, ArrowDownRight, ArrowUpLeft, ArrowUpRight, Cat, Check, ChevronRight, Code2, Crosshair, Expand, Gamepad2, Heart, Info, Keyboard, Mouse, Pause, Play, RotateCcw, Settings2, Smartphone, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { BongoCat } from '@/components/bongo-cat';
import { useBongoInput, type DemoInput } from '@/hooks/use-bongo-input';

export const Route = createFileRoute('/')({
  head: () => ({ meta: [
    { title: 'Bongo Cat Mobile — Seu duo mais fofo' },
    { name: 'description', content: 'Personalize seu Bongo Cat e experimente as patinhas com WASD, espaço e mouse. Demonstração web para futura integração Android.' },
    { property: 'og:title', content: 'Bongo Cat Mobile — Seu duo mais fofo' },
    { property: 'og:description', content: 'Um gatinho para acompanhar cada jogada. Experimente e personalize sua demonstração interativa.' },
    { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary_large_image' },
  ] }),
  component: Index,
});

const positions = [
  { id: 'top-left', label: 'Superior esquerdo', Icon: ArrowUpLeft },
  { id: 'top-right', label: 'Superior direito', Icon: ArrowUpRight },
  { id: 'bottom-left', label: 'Inferior esquerdo', Icon: ArrowDownLeft },
  { id: 'bottom-right', label: 'Inferior direito', Icon: ArrowDownRight },
];

function Index() {
  const [enabled, setEnabled] = useState(true);
  const [size, setSize] = useState(100);
  const [position, setPosition] = useState('bottom-right');
  const [positionTouched, setPositionTouched] = useState(false);
  const [showIntegration, setShowIntegration] = useState(false);
  const { pressed, count, lastInput, inputHandlers, stageHandlers, mouseOffset } = useBongoInput();
  const reset = () => { setEnabled(true); setSize(100); setPosition('bottom-right'); setPositionTouched(false); };
  const keyButton = (key: DemoInput, label: string, extra = '') => <Button variant="key" className={extra} data-pressed={pressed.has(key)} aria-label={key === 'SPACE' ? 'Tecla Espaço' : `Tecla ${label}`} {...inputHandlers(key)}>{label}</Button>;

  return (
    <div className="app-shell">
      <header className="app-header">
        <a className="brand" href="/" aria-label="Bongo Cat Mobile, início"><span className="brand-mark"><Cat /></span><span>Bongo Cat<span className="brand-mobile">mobile</span></span></a>
        <div className="header-right"><span className="web-badge"><span />Demo web</span><span className="version">v0.1</span><span className="header-divider" /><a className="android-link" href="#android"><Smartphone size={16} /><span>Projeto Android</span><ChevronRight size={14} /></a></div>
      </header>

      <main className="main-content">
        <section className="intro">
          <div className="eyebrow"><Gamepad2 size={14} /> SEU NOVO DUO NO FREE FIRE</div>
          <h1>Cada jogada, uma <span>patinha.</span></h1>
          <p>Seu setup ganhou um companheiro. Do seu jeito, no seu ritmo.</p>
        </section>

        <div className="workspace">
          <section className="preview-panel" aria-label="Prévia do Bongo Cat">
            <div className="panel-heading"><span><span className={`status-dot ${enabled ? '' : 'is-paused'}`} />Prévia ao vivo</span><span className="subtle-label"><Crosshair size={13} /> Ambiente de teste</span></div>
            <div className={`cat-stage ${enabled ? 'is-running' : ''}`} data-position={positionTouched ? position : 'center'} {...stageHandlers}>
              <span className="stage-corner corner-tl" /><span className="stage-corner corner-tr" /><span className="stage-corner corner-bl" /><span className="stage-corner corner-br" />
              <span className="stage-tag"><Sparkles size={12} /> BONGO CAT</span>
              <div className="cat-placement"><BongoCat pressed={pressed} mouseOffset={mouseOffset} enabled={enabled} size={size} /></div>
              <span className="stage-caption">{enabled ? 'Pronto para acompanhar você' : 'Patinhas em pausa'}<Heart size={12} /></span>
            </div>
            <div className="preview-toolbar"><span className="state-label">{enabled ? <><span className="status-dot" /> Animações ativas</> : <><Pause size={13} /> Animações pausadas</>}</span><Button variant="ghost" size="sm" onClick={() => setEnabled(value => !value)}>{enabled ? <Pause /> : <Play />}{enabled ? 'Pausar' : 'Ativar'}</Button></div>
          </section>

          <section className="settings-panel" aria-labelledby="settings-title">
            <div className="settings-heading"><Settings2 size={18} /><h2 id="settings-title">Do seu jeito</h2><Button variant="ghost" size="icon" title="Restaurar ajustes" aria-label="Restaurar ajustes" onClick={reset}><RotateCcw /></Button></div>
            <div className="setting-row"><div><label htmlFor="animations">Animações das patinhas</label><p>Um toque de vida no seu setup</p></div><Switch id="animations" checked={enabled} onCheckedChange={setEnabled} /></div>
            <div className="setting-block"><div className="setting-title"><label id="size-label"><Expand size={15} />Tamanho do gato</label><output>{size}%</output></div><Slider aria-labelledby="size-label" min={50} max={150} step={5} value={[size]} onValueChange={values => setSize(values[0] ?? 100)} /><div className="range-labels"><span>Pequeno</span><span>Grande</span></div></div>
            <div className="setting-block position-setting"><div className="setting-title"><label><Crosshair size={15} />Posição na tela</label></div><div className="position-grid">{positions.map(({ id, label, Icon }) => <Button key={id} variant="position" aria-label={label} aria-pressed={position === id} title={label} data-selected={position === id} onClick={() => { setPosition(id); setPositionTouched(true); }}><Icon /><span className={`position-mini ${id}`} /></Button>)}</div><p className="position-label">{positions.find(item => item.id === position)?.label}<Check size={12} /></p></div>
            <div className="setting-note"><Info size={15} /><p>Estes ajustes se aplicam à prévia.<br />A sobreposição Android vem depois.</p></div>
          </section>

          <section className="demo-panel" aria-labelledby="demo-title">
            <div className="demo-heading"><div><Keyboard size={18} /><h2 id="demo-title">Hora de dar um play</h2></div><span className="input-counter">{count} <span>toques</span></span></div>
            <p className="section-description">Toque nos controles ou use seu teclado e mouse nesta página.</p>
            <div className="input-controls"><div className="keyboard-controls"><div className="wasd"><div className="w-key">{keyButton('W', 'W')}</div><div className="asd-keys">{keyButton('A', 'A')}{keyButton('S', 'S')}{keyButton('D', 'D')}</div></div>{keyButton('SPACE', 'Espaço', 'space-key')}</div><div className="input-divider" /><div className="mouse-controls"><Button variant="key" className="mouse-key" data-pressed={pressed.has('LEFT')} aria-label="Clique esquerdo" {...inputHandlers('LEFT')}><Mouse /><span>Esquerdo</span></Button><Button variant="key" className="mouse-key" data-pressed={pressed.has('RIGHT')} aria-label="Clique direito" {...inputHandlers('RIGHT')} onContextMenu={event => event.preventDefault()}><Mouse /><span>Direito</span></Button></div></div>
            <div className="demo-foot"><span><span className="status-dot" />{lastInput ? `Último toque: ${lastInput === 'SPACE' ? 'Espaço' : lastInput === 'LEFT' ? 'Mouse esquerdo' : lastInput === 'RIGHT' ? 'Mouse direito' : lastInput}` : 'Aguardando seu primeiro toque'}</span><span>Somente nesta página</span></div>
          </section>

          <section className="android-panel" id="android"><div className="android-heading"><span className="android-icon"><Smartphone size={20} /></span><span className="coming-badge">PRÓXIMO CAPÍTULO</span></div><h2>Pequeno gato.<br />Grandes planos.</h2><p>A sobreposição flutuante e a leitura de comandos no Free Fire precisam de um aplicativo Android nativo.</p><Button variant="ghost" className="integration-button" onClick={() => setShowIntegration(value => !value)} aria-expanded={showIntegration}>Sobre a integração <ChevronRight className={showIntegration ? 'rotate-90' : ''} /></Button>{showIntegration && <div className="integration-details"><Code2 size={16} /><p>Esta demo não acessa outros apps. A futura versão Android deverá gerenciar permissões de sobreposição e enviar eventos ao gato por uma ponte nativa. Nenhuma conexão nativa está ativa.</p></div>}</section>
        </div>
        <div className="privacy-note"><Info size={15} /><p>Um espaço seguro para testar: este site não detecta teclas ou cliques em outros aplicativos Android.</p></div>
      </main>
      <footer className="app-footer"><span>Feito para jogar. Criado para sorrir.<Heart size={12} /></span><span>Bongo Cat Mobile <span className="footer-dot">·</span> Projeto independente</span></footer>
    </div>
  );
}
