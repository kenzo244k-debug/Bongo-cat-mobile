plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.bongocat.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.bongocat.mobile"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1.0-native-preview"
    }
}
