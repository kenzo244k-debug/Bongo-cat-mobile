package com.bongocat.mobile

import android.accessibilityservice.AccessibilityService
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/** Observa teclas físicas e SEMPRE as deixa seguir para o jogo/aplicativo. */
class CatAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { super.onServiceConnected() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val key = when (event.keyCode) {
            KeyEvent.KEYCODE_W -> "W"
            KeyEvent.KEYCODE_A -> "A"
            KeyEvent.KEYCODE_S -> "S"
            KeyEvent.KEYCODE_D -> "D"
            KeyEvent.KEYCODE_SPACE -> "SPACE"
            else -> null
        }
        if (key != null) {
            when (event.action) {
                KeyEvent.ACTION_DOWN -> CatEventBus.emit(key, true)
                KeyEvent.ACTION_UP -> CatEventBus.emit(key, false)
            }
        }
        // false = não consumir; Android continua encaminhando o evento ao aplicativo em foco.
        return false
    }
}
