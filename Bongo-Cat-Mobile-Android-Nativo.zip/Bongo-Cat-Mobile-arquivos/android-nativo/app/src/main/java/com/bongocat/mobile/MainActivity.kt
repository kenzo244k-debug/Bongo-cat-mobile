package com.bongocat.mobile

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var size = 190
    private var position = "center"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF101827.toInt()) }
        val heading = TextView(this).apply {
            text = "BONGO CAT MOBILE  •  CONTROLES NATIVOS"
            setTextColor(0xFFFFFFFF.toInt()); textSize = 14f; setPadding(16, 14, 16, 8)
        }
        page.addView(heading)
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8, 4, 8, 4) }
        row1.addView(btn("Ativar sobreposição") { requestOverlayAndStart() }, weight())
        row1.addView(btn("Ocultar gato") { stopOverlay() }, weight())
        page.addView(row1)
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8, 4, 8, 4) }
        row2.addView(btn("Ativar teclado") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, weight())
        row2.addView(btn("− tamanho") { changeSize(-20) }, weight())
        row2.addView(btn("+ tamanho") { changeSize(20) }, weight())
        page.addView(row2)
        val row3 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8, 4, 8, 8) }
        row3.addView(btn("Esquerda") { setPosition("left") }, weight())
        row3.addView(btn("Centro") { setPosition("center") }, weight())
        row3.addView(btn("Direita") { setPosition("right") }, weight())
        page.addView(row3)
        val web = WebView(this).apply {
            setBackgroundColor(0xFF101827.toInt())
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            loadUrl("file:///android_asset/index.html")
        }
        page.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(page)
    }

    private fun weight() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 0, 3, 0) }
    private fun btn(label: String, action: () -> Unit) = Button(this).apply { text = label; textSize = 11f; setOnClickListener { action() } }

    private fun requestOverlayAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Permita que o Bongo Cat apareça sobre outros apps e volte aqui.", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(this, CatOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "Sobreposição iniciada. Ative também o serviço de teclado.", Toast.LENGTH_LONG).show()
    }

    private fun stopOverlay() { startService(Intent(this, CatOverlayService::class.java).setAction(CatOverlayService.ACTION_HIDE)) }
    private fun changeSize(delta: Int) {
        size = (size + delta).coerceIn(120, 300)
        startService(Intent(this, CatOverlayService::class.java).setAction(CatOverlayService.ACTION_SIZE).putExtra(CatOverlayService.EXTRA_SIZE, size))
    }
    private fun setPosition(value: String) {
        position = value
        startService(Intent(this, CatOverlayService::class.java).setAction(CatOverlayService.ACTION_POSITION).putExtra(CatOverlayService.EXTRA_POSITION, value))
    }
}
