package com.bongocat.mobile

import android.os.Handler
import android.os.Looper

/** Eventos de teclas observados pelo AccessibilityService e enviados à janela flutuante. */
object CatEventBus {
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var sink: ((String, Boolean) -> Unit)? = null

    fun attach(listener: ((String, Boolean) -> Unit)?) { sink = listener }
    fun emit(key: String, down: Boolean) {
        main.post { sink?.invoke(key, down) }
    }
}
