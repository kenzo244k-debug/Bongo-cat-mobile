package com.bongocat.mobile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.FrameLayout

class CatOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var root: FrameLayout? = null
    private var catWeb: WebView? = null
    private var sizeDp = 190
    private var position = "center"
    private val pressed = linkedSetOf<String>()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startAsForeground()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        CatEventBus.attach { key, down ->
            if (down) pressed.add(key) else pressed.remove(key)
            updateKeys()
        }
        createOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_HIDE -> { removeOverlay(); stopSelf(); return START_NOT_STICKY }
            ACTION_SIZE -> { sizeDp = (intent.getIntExtra(EXTRA_SIZE, sizeDp)).coerceIn(120, 300); resizeOverlay() }
            ACTION_POSITION -> { position = intent.getStringExtra(EXTRA_POSITION) ?: "center"; resizeOverlay() }
        }
        if (root == null) createOverlay()
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL, "Bongo Cat", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun startAsForeground() {
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Bongo Cat ativo")
                .setContentText("A animação flutuante está pronta")
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Bongo Cat ativo").setOngoing(true).build()
        }
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(42, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(42, notification)
    }

    private fun createOverlay() {
        if (!android.provider.Settings.canDrawOverlays(this) || root != null) return
        val web = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = false
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.cacheMode = WebSettings.LOAD_NO_CACHE
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            loadUrl("file:///android_asset/overlay.html")
        }
        val container = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            addView(web, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }
        root = container
        catWeb = web
        val params = layoutParams()
        try { windowManager.addView(container, params) } catch (_: Exception) { root = null; catWeb = null }
    }

    private fun layoutParams(): WindowManager.LayoutParams {
        val width = (sizeDp * resources.displayMetrics.density * 1.85f).toInt()
        val height = (sizeDp * resources.displayMetrics.density * 1.20f).toInt()
        val gravity = when (position) {
            "left" -> Gravity.BOTTOM or Gravity.START
            "right" -> Gravity.BOTTOM or Gravity.END
            else -> Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        }
        return WindowManager.LayoutParams(
            width, height, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            this.gravity = gravity
            y = (24 * resources.displayMetrics.density).toInt()
            x = (12 * resources.displayMetrics.density).toInt()
        }
    }

    private fun resizeOverlay() {
        val view = root ?: return
        try { windowManager.updateViewLayout(view, layoutParams()) } catch (_: Exception) { }
    }

    private fun updateKeys() {
        val json = pressed.joinToString(prefix = "[", postfix = "]") { "\"$it\"" }
        catWeb?.post { catWeb?.evaluateJavascript("window.setPressedKeys && window.setPressedKeys($json)", null) }
    }

    private fun removeOverlay() {
        CatEventBus.attach(null)
        root?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        root = null; catWeb = null
    }

    override fun onDestroy() { removeOverlay(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_HIDE = "com.bongocat.mobile.HIDE"
        const val ACTION_SIZE = "com.bongocat.mobile.SIZE"
        const val ACTION_POSITION = "com.bongocat.mobile.POSITION"
        const val EXTRA_SIZE = "size"
        const val EXTRA_POSITION = "position"
        private const val CHANNEL = "bongo_overlay"
    }
}
