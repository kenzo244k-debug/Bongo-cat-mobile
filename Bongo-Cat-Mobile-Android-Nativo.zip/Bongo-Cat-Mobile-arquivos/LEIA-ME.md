# Bongo Cat Mobile — pacote atualizado

O pacote mantém a versão web original e acrescenta `android-nativo/`, um projeto Android Studio em Kotlin para a sobreposição real.

## Qual versão usar

- `android-nativo/`: caminho recomendado para testar a janela flutuante nativa sobre outros aplicativos.
- `web-para-conversor/`: demonstração web original. Ela responde a teclado/mouse apenas enquanto a página está aberta; não consegue ficar por cima de outros aplicativos por conta própria.
- `codigo-fonte/`: fonte React/TypeScript original.

## Recursos nativos nesta prévia

- Sobreposição transparente com `FLAG_NOT_TOUCHABLE`, para não bloquear os toques do jogo.
- Teclado físico: observação de W, A, S, D e Espaço pelo AccessibilityService, sem consumir os eventos.
- Controles nativos para iniciar/ocultar, alterar tamanho e escolher esquerda/centro/direita.

## Limitações importantes

A sincronização com toque na tela e mouse ainda não está implementada. A API Android de eventos genéricos de movimento não garante observação sem interferência: as fontes solicitadas não são encaminhadas aos outros aplicativos. Por isso, o projeto não captura eventos de mouse. O Android também não oferece uma API pública geral para um app observar cada toque feito dentro do Free Fire enquanto mantém esses toques intactos.

## Compilação

Abra `android-nativo/` no Android Studio e siga `ANDROID-NATIVO-LEIA-ME.md`. O ZIP contém código-fonte, não APK pronto. A compilação e o teste final precisam ser feitos com Android SDK e aparelho real.
