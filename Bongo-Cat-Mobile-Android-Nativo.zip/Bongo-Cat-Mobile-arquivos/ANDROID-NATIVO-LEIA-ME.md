# Bongo Cat Mobile — módulo Android nativo (prévia técnica)

Esta pasta acrescenta um projeto Android Studio em Kotlin ao projeto web original.

## O que foi implementado

- Activity Android que mantém a experiência web original dentro de um WebView.
- Serviço de sobreposição com janela `TYPE_APPLICATION_OVERLAY`.
- Janela flutuante transparente e `FLAG_NOT_TOUCHABLE`, para que os toques na tela continuem chegando ao jogo.
- Serviço de acessibilidade configurado para observar teclas de um teclado físico.
- O callback `onKeyEvent` reconhece W, A, S, D e Espaço e retorna `false`, deixando os eventos seguirem para o aplicativo em foco.
- Gatinho em HTML/SVG transparente, separado da tela principal, com animação por tecla.
- Controles para iniciar/parar, tamanho e posição esquerda/centro/direita.

## Limitações reais desta prévia

1. A sincronização implementada é para teclado físico. Acessibilidade não oferece uma forma geral e sem interferência de observar todos os toques que o jogador faz na tela.
2. O callback Android `onMotionEvent` pode receber fontes genéricas, mas as fontes solicitadas não são encaminhadas ao restante do sistema. Por isso, esta versão não se inscreve em eventos de mouse: capturá-los poderia impedir que chegassem ao jogo.
3. A animação por toque na tela e por mouse ainda não está implementada. O overlay, porém, é não tocável e não deve bloquear os toques do jogador.
4. Fabricantes podem aplicar restrições próprias a serviços em segundo plano e sobreposições. É necessário compilar e testar no aparelho real.
5. A permissão de acessibilidade é ativada manualmente pelo usuário nas configurações do Android. O serviço não tenta ativar-se sozinho.
6. O tipo de serviço em primeiro plano `specialUse` é declarado para manter a sobreposição enquanto o usuário joga. A distribuição em lojas pode exigir justificativa/revisão adicional; para teste privado, instale a compilação local.

## Compilar no Android Studio

1. Abra a pasta `android-nativo` no Android Studio.
2. Aguarde a sincronização do Gradle. O projeto usa Android Gradle Plugin 8.7.3, Kotlin 2.0.21 e compileSdk 35.
3. Se solicitado, instale Android SDK Platform 35 e um JDK compatível com o Android Gradle Plugin.
4. Execute no aparelho Android 14 ou superior.
5. No app, toque em **Ativar sobreposição** e conceda a permissão do Android.
6. Volte ao app, toque em **Ativar teclado** e habilite o serviço “Bongo Cat — teclas externas”.
7. Conecte um teclado físico e teste WASD/Espaço primeiro fora do jogo. Depois teste no jogo, confirmando que as teclas continuam funcionando.

## Estrutura

- `app/src/main/assets/index.html`, `app.js`, `styles.css`: pacote web original.
- `app/src/main/assets/overlay.html`: gatinho transparente para a janela flutuante.
- `app/src/main/java/...`: Activity, serviço de overlay, serviço de acessibilidade e barramento de eventos.

## Estado da entrega

É um projeto-fonte Android nativo preparado para abrir e compilar no Android Studio. Não é um APK compilado ou assinado. Não foi possível validar a compilação nem o comportamento no Infinix físico neste ambiente sem Android SDK/aparelho conectado.
